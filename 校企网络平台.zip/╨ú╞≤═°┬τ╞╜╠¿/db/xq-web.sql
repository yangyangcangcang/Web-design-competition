SHOW CREATE DATABASE xq_web
SHOW TABLES
-- 创建高校表
CREATE TABLE university(
	id INT PRIMARY KEY AUTO_INCREMENT,
	teacherName VARCHAR(10),
	major VARCHAR(20),
	universityName VARCHAR(20),
	teacherId VARCHAR(20),
	email VARCHAR(20)
)
ALTER TABLE enterprise ADD COLUMN enterpriseId VARCHAR(20);
-- 初始化数据
INSERT INTO university(teacherName,major,universityName,teacherId,email) 
VALUES('杨白菜','有限元分析','太原科技大学','12345','90214899@qq.com')

SELECT *FROM university

-- 创建企业表
CREATE TABLE enterprise(
	id INT PRIMARY KEY AUTO_INCREMENT,
	businessPerson VARCHAR(20),
	asset VARCHAR(30),
	email VARCHAR(20)
)
ALTER TABLE enterprise ADD COLUMN enterpriseId VARCHAR(20);
ALTER TABLE enterprise ADD COLUMN enterpriseName VARCHAR(20);

-- 初始化数据
INSERT INTO enterprise(businessPerson,asset,enterpriseId,email)
VALUES ('太原重型机械有限公司','500万','0351','taiyuanzhonggong@sina.com')
SELECT *FROM enterprise
-- 创建投资人表
CREATE TABLE investor(
	id INT PRIMARY KEY AUTO_INCREMENT,
	investorName VARCHAR(10),
	domain VARCHAR(20),
	email VARCHAR(20)
)
INSERT INTO investor(investorName,domain,email) VALUES ('李小龙','有限元法分析','8234565894@qq.com')
SELECT *FROM investor
CREATE TABLE users(
	id INT PRIMARY KEY AUTO_INCREMENT,
	userName VARCHAR(20),
	pwd  VARCHAR(20)
 )
SELECT *FROM users WHERE userName= AND pwd